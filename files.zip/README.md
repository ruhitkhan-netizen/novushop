# NovuShop — E-Commerce Web App

A fully functional front-end e-commerce application built with HTML, CSS, and vanilla JavaScript. No frameworks, no build tools — just open `index.html` and it runs.

## Live Demo

> Deploy to GitHub Pages: `Settings → Pages → Deploy from branch (main) → / (root)`  
> Your live URL will be: `https://<your-username>.github.io/<your-repo-name>/`

## Features

- 🛍️ **18 products** across 4 categories (Electronics, Gear, Lifestyle, Office)
- 🔍 **Live search** — filters products as you type
- 🗂️ **Category filter** — filter by Electronics, Gear, Lifestyle, Office
- 🛒 **Shopping cart** — add items, adjust quantity, remove items
- 💰 **Order summary** — subtotal, 8% tax, and total calculated live
- ✅ **Checkout flow** — clears cart and confirms order with total
- 📱 **Fully responsive** — works on mobile, tablet, and desktop

## How to Run

### Option 1 — Open locally
```
Double-click index.html
```
No server required. Works in any modern browser.

### Option 2 — GitHub Pages (required for submission)
1. Create a new GitHub repository
2. Upload all three files: `index.html`, `style.css`, `app.js`
3. Go to **Settings → Pages**
4. Under *Source*, select **Deploy from a branch**
5. Choose **main** branch and **/ (root)** folder
6. Click Save — your site will be live in ~60 seconds

## File Structure

```
├── index.html   # App structure and layout
├── style.css    # All styles and responsive design
├── app.js       # Product data, cart logic, rendering
└── README.md    # This file
```

## Technologies

| Technology | Purpose |
|---|---|
| HTML5 | Page structure and semantic markup |
| CSS3 | Styling, grid layout, animations, responsive design |
| JavaScript (ES6+) | Product data, cart state, DOM rendering, event handling |

## Author

Midterm Project — Web Programming
